var car,wall;
var speed,weight;
car.velocityX = 15;


function setup() {
  createCanvas(800,400);
  
  
 
}
 function draw() {
  background(0,190,255);  
  car = createSprite(400,260,50,25);
  wall = createSprite(750,200,50,150);
  speed = random(100,200);
  weight = random(400,1500);
  car.width = 50;
  car.height = 25;
  wall.x = 750;
  wall.y = 200;
  car.shapeColor = "yellow";
  wall.shapeColor = "brown";
  if(car.isTouching(wall)) {
    car.destroy();
  }
  
  if(speed > 180 && weight > 950) {
    car.shapeColor = "green";
  }
  if(speed < 181 && weight < 951) {
    car.shapeColor = "red";
  }
  drawSprites();
}
